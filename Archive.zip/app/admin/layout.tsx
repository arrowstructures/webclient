"use client";

import { ReactNode, useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

import { AppSidebar } from "@/components/app-sidebar";
import { Separator } from "@/components/ui/separator";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import Breadcrumbs from "@/components/breadcrumbs";
import { useAuth } from "@/providers/supabase-auth-provider";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { UserProfile } from "@/components/user-profile";

export default function AdminLayout({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const { user, isLoading } = useAuth();
  const pathname = usePathname();

  // Determine if we're on the public articles page
  const isPublicArticlesPage = pathname === "/public-articles";

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session?.user) {
        router.replace("/login"); // redirect if not authenticated
      }

      setLoading(false);
    };

    checkAuth();
  }, [router]);

  if (loading) return <p>Loading...</p>;

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="bg-gray-50 flex flex-col relative flex-1">
        <header className="sticky top-0 flex !h-16 shrink-0 items-center gap-2 transition-[width,height] ease-linear group-has-[[data-collapsible=icon]]/sidebar-wrapper:h-12 bg-white border-b px-4">
          <div className="flex items-center gap-2">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumbs />
          </div>
          <div className="flex items-center gap-4 ml-auto">
            {!isLoading && (
              <>
                {user ? (
                  <>
                    {/* Show link to admin dashboard for authenticated users */}
                    {isPublicArticlesPage && (
                      <Link href="/articles">
                        <Button variant="outline">Admin Dashboard</Button>
                      </Link>
                    )}
                    <UserProfile />
                  </>
                ) : (
                  <>
                    {/* Show auth links for non-authenticated users */}
                    <Link href="/auth/login">
                      <Button variant="ghost">Sign In</Button>
                    </Link>
                    <Link href="/auth/register">
                      <Button>Sign Up</Button>
                    </Link>
                  </>
                )}
              </>
            )}
          </div>
        </header>
        <div className="p-4 pt-0 w-full">{children}</div>
      </SidebarInset>
    </SidebarProvider>
  );
}
