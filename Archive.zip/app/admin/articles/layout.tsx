"use client";

import type React from "react";
import { usePathname } from "next/navigation";
import { useRequireAuth } from "@/hooks/use-require-auth";
import { Loader2 } from "lucide-react";
import { useMemo } from "react";

export default function ArticlesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const isViewRoute = pathname.startsWith("/articles/view/");

  // Only require auth for non-view routes
  const auth = useRequireAuth();
  const isLoading = useMemo(() => {
    return !isViewRoute ? auth.isLoading : false;
  }, [isViewRoute, auth.isLoading]);

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return <main className="flex-1">{children}</main>;
}
