import { redirect } from "next/navigation";

function AdminPage() {
  return redirect("/admin/articles");
}

export default AdminPage;
