import { ArticleForm } from "@/components/articles/article-form"
import { Button } from "@/components/ui/button"
import { ChevronLeft } from "lucide-react"
import Link from "next/link"

export default function NewArticlePage() {
  return (
    <div className="container mx-auto py-8">
      <div className="mb-6">
        <Link href="/articles">
          <Button variant="ghost" className="pl-0">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Articles
          </Button>
        </Link>
        <h1 className="text-3xl font-bold mt-2">Create New Article</h1>
        <p className="text-muted-foreground mt-1">Create a new article for your newsletter</p>
      </div>

      <div className="bg-white rounded-md border p-6">
        <ArticleForm />
      </div>
    </div>
  )
}
