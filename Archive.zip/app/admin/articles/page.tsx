import { ArticlesHeader } from "@/components/articles/articles-header";
import { ArticlesTable } from "@/components/articles/articles-table";

export default function ArticlesPage() {
  return (
    <div className="mx-auto py-8 px-8 flex flex-col">
      <ArticlesHeader />
      <div className="mt-8">
        <ArticlesTable />
      </div>
    </div>
  );
}
