import Image from "next/image"
import "./loading"
import { Award, Users, Building, Lightbulb } from "lucide-react"

type TeamMember = {
  name: string
  role: string
  image: string
  bio: string
}

export default function AboutPage() {
  const stats = [
    { icon: Building, value: "500+", label: "Projects Completed" },
    { icon: Users, value: "50+", label: "Team Members" },
    { icon: Award, value: "25+", label: "Awards Won" },
    { icon: Lightbulb, value: "15+", label: "Years Experience" },
  ]

  const team: TeamMember[] = [
    {
      name: "John Smith",
      role: "Principal Architect",
      image: "/team1.jpg?height=400&width=400",
      bio: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vitae eros eget tellus tristique bibendum.",
    },
    {
      name: "Sarah Johnson",
      role: "Design Director",
      image: "/placeholder.svg?height=400&width=400",
      bio: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    },
    {
      name: "Michael Brown",
      role: "Project Manager",
      image: "/placeholder.svg?height=400&width=400",
      bio: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.",
    },
    {
      name: "Emily Davis",
      role: "Interior Designer",
      image: "/placeholder.svg?height=400&width=400",
      bio: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.",
    },
  ]

  return (
    <>
      <section className="bg-muted py-12 md:py-24">
        <div className="container">
          <div className="grid gap-12 md:grid-cols-2">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">About Arrow Structures</h1>
              <p className="text-xl text-muted-foreground">
                Founded in 2017, Arrow Structures has steadily grown into one of the leading Structural Consultancy and Civil Construction firms in the region. Spearheaded by Dr. Prabu Dev, M.E., Ph.D., our Principal Structural Engineer, the company was built on a foundation of technical excellence, quality commitment, and client-centric values.
                At Arrow Structures, we believe that every structure tells a story — and we make sure yours is built with strength, elegance, and trust.
                From concept to completion, we ensure that all our projects meet industry standards while maintaining the perfect balance between quality, cost-efficiency, serviceability, and sustainability. We take pride in delivering timely solutions tailored to the unique needs of our clients, whether it&apos;s a compact residential space or a complex industrial facility.
                Our passion for structures isn&apos;t just about building — it&apos;s about building better, smarter, and stronger. This dedication fuels our steady growth and empowers us to take on increasingly diverse and challenging projects.
              </p>
            </div>
            <div className="relative h-[500px] w-full overflow-hidden rounded-lg">
              <Image
                src="/home.jpg"
                alt="Office"
                fill
                className="object-cover"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24">
        <div className="container">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((stat) => (
              <div key={stat.label} className="flex flex-col items-center space-y-2 text-center">
                <stat.icon className="h-12 w-12 text-primary" />
                <div className="text-3xl font-bold">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t bg-muted py-12 md:py-24">
        <div className="container">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Mission & Vision</h2>
          <div className="mt-8 grid gap-12 md:grid-cols-3">
            <p className="text-muted-foreground">
              To create innovative architectural solutions that enhance the way people live, work, and interact with
              their environment.
            </p>
            <p className="text-muted-foreground">
              To promote sustainable design practices that minimize environmental impact while maximizing comfort and
              functionality.
            </p>
            <p className="text-muted-foreground">
              To collaborate with our clients in bringing their architectural visions to life through creative and
              practical solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-12 md:py-24">
  <div className="container mx-auto px-4">
    <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-center mb-12">
      Meet Our Team
    </h2>
    <div className="flex flex-col divide-y divide-gray-300">
      {team.map((member, index) => {
        const isFirst = index === 0
        return (
          <div
            key={member.name}
            className={`flex items-center justify-between py-8 ${
              isFirst ? "flex-row-reverse" : "flex-row"
            }`}
          >
            {/* Image */}
            <div className="w-[150px] h-[150px] flex-shrink-0">
              <Image
                src={member.image}
                alt={member.name}
                width={150}
                height={150}
                className="object-cover rounded-md w-full h-full"
              />
            </div>

            {/* Text container */}
            <div
              className={`max-w-2xl ${
                isFirst ? "text-left" : "text-right"
              } flex flex-col ${
                isFirst ? "items-start" : "items-end"
              }`}
            >
              <div className="text-2xl font-semibold">{member.name}</div>
              <div className="text-lg text-muted-foreground">{member.role}</div>
              <p className="mt-2 text-sm text-muted-foreground">{member.bio}</p>
            </div>
          </div>
        )
      })}
    </div>
  </div>
</section>


    </>
  )
}
