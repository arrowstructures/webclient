"use client";

import { ArticleForm } from "@/components/articles/article-form";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/lib/supabase";
import { ChevronLeft } from "lucide-react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import type { ArticleClient } from "@/types/article";
import { CATEGORIES } from "@/lib/constants";

// Helper function to convert snake_case to camelCase (updated for new schema)
const snakeToCamel = (article: any): ArticleClient => {
  // Find the category label from the category value
  const categoryObj = CATEGORIES.find((c) => c.value === article.category);
  const categoryLabel = categoryObj ? categoryObj.label : article.category;

  // Generate thumbnail URL from thumbnail_path
  const thumbnail = article.thumbnail_path
    ? supabase.storage.from("articles").getPublicUrl(article.thumbnail_path)
        .data.publicUrl
    : null;

  // Ensure content is properly handled
  const content = article.content || "";
  console.log("Article content from database:", content);

  return {
    id: article.id,
    title: article.title,
    slug: article.slug,
    content: content,
    thumbnailPath: article.thumbnail_path,
    thumbnail: thumbnail,
    category: article.category,
    categoryLabel: categoryLabel,
    author: article.author,
    views: article.views,
    status: article.status,
    isBreaking: article.is_breaking,
    createdAt: new Date(article.created_at),
    userId: article.user_id,
  };
};

export default function EditArticlePage() {
  const params = useParams();
  const slug = params.slug as string;
  const [article, setArticle] = useState<ArticleClient | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  // Fetch article directly instead of using the hook to avoid dependency issues
  useEffect(() => {
    const fetchArticle = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from("articles")
          .select("*")
          .eq("slug", slug)
          .single();

        if (error) {
          throw error;
        }

        console.log("Raw article data from database:", data);
        const processedArticle = snakeToCamel(data);
        console.log("Processed article:", processedArticle);
        setArticle(processedArticle);
      } catch (err) {
        console.error("Error fetching article:", err);
        setError(err as Error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchArticle();
  }, [slug]); // Only depend on the slug

  return (
    <div className="container mx-auto py-8">
      <div className="mb-6">
        <Link href="/admin/articles">
          <Button variant="ghost" className="pl-0">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Articles
          </Button>
        </Link>

        {isLoading ? (
          <>
            <Skeleton className="h-10 w-1/3 mt-2" />
            <Skeleton className="h-5 w-1/4 mt-2" />
          </>
        ) : error ? (
          <div className="text-red-500 mt-2">
            Error loading article: {error.message}
          </div>
        ) : (
          <>
            <h1 className="text-3xl font-bold mt-2">Edit Article</h1>
            <p className="text-muted-foreground mt-1">{article?.title}</p>
          </>
        )}
      </div>

      <div className="bg-white rounded-md border p-6">
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : error ? (
          <div className="text-center py-8">
            <p className="text-red-500">Failed to load article</p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => window.location.reload()}
            >
              Try Again
            </Button>
          </div>
        ) : (
          article && <ArticleForm article={article} />
        )}
      </div>
    </div>
  );
}
